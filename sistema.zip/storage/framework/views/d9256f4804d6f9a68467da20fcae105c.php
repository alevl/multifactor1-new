<div>
    <?php if (isset($component)) { $__componentOriginal469697c8a3c244cba6b653458854f352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal469697c8a3c244cba6b653458854f352 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\MenuFranquicia::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.menu-franquicia'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\MenuFranquicia::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="container">
            <span class="text-2xl font-semi-bold leading-normal"><?php echo e(__('Data')); ?></span>
            <div class="col-12" style="overflow-x: auto">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-4 p-2 rounded">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-full">
                            <div class="mt-2 relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700 rounded" style="height: 500px; overflow-x: auto;">
                                <div class="text-xs texto-primero font-semibold mb-2"><?php echo e("ID ".$maq->id_maquina." - ".$maq->nombre); ?></div>
                                <table class="w-full min-w-max">
                                    <thead>
                                        <tr class="text-center">
                                        <th class="p-0">
                                            <div class="py-3 px-2 rounded-l-xl fondo-primero"><span class="text-xs font-semibold text-white">Fecha</span></div>
                                        </th>
                                        <th class="p-0">
                                            <div class="py-3 px-2 fondo-primero"><span class="text-xs text-white font-semibold">Hora</span></div>
                                        </th>
                                        <th class="p-0">
                                            <div class="py-3 px-2 fondo-primero"><span class="text-xs text-white font-semibold">Temperatura</span></div>
                                        </th>
                                        <th class="p-0">
                                            <div class="py-3 px-2 fondo-primero rounded-r-xl"><span class="text-xs text-white font-semibold">Humedad</span></div>
                                        </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $n=0 ?>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lecturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!--[if BLOCK]><![endif]--><?php if($maq->id == $lec->maquina): ?>
                                                <!--[if BLOCK]><![endif]--><?php if($n==0): ?>
                                                    <?php $n=1 ?>
                                                    <tr>
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->fecha); ?></h5>
                                                            </div>
                                                        </td>
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->hora); ?></h5>
                                                            </div>
                                                        </td>
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->temperatura." °C"); ?></h5>
                                                            </div>
                                                        </td>
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->humedad." RH%"); ?></h5>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php else: ?>
                                                    <?php $n=0 ?>
                                                    <tr style="background-color: #f2f3f4">
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->fecha); ?></h5>
                                                            </div>
                                                        </td>
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->hora); ?></h5>
                                                            </div>
                                                        </td>
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->temperatura." °C"); ?></h5>
                                                            </div>
                                                        </td>
                                                        <td class="p-0 text-center">
                                                            <div class="h-8 p-2">
                                                            <h5 class="text-sm font-medium text-xs texto-blanco"><?php echo e($lec->humedad." RH%"); ?></h5>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal469697c8a3c244cba6b653458854f352)): ?>
<?php $attributes = $__attributesOriginal469697c8a3c244cba6b653458854f352; ?>
<?php unset($__attributesOriginal469697c8a3c244cba6b653458854f352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal469697c8a3c244cba6b653458854f352)): ?>
<?php $component = $__componentOriginal469697c8a3c244cba6b653458854f352; ?>
<?php unset($__componentOriginal469697c8a3c244cba6b653458854f352); ?>
<?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\multifactor1-new\resources\views/livewire/franquiciado/lecturas-f.blade.php ENDPATH**/ ?>