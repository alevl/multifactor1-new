<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'inline-flex items-center uppercase justify-center px-4 py-2 border border border-primary rounded font-semibold text-xs tracking-widest hover:text-blue-300 focus:outline-none focus:ring-2 focus:ring-offset-2 transition ease-in-out duration-150 fondo-rojo text-white'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\xampp\htdocs\multifactor1-new\resources\views/components/boton-secundario.blade.php ENDPATH**/ ?>