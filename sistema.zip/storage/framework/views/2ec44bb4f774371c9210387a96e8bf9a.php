<div>
    <?php if (isset($component)) { $__componentOriginal8e86184e23470ccb5b55720dccb4a286 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e86184e23470ccb5b55720dccb4a286 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\MenuAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.menu-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\MenuAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="container">
            <span class="text-2xl font-semi-bold leading-normal"><?php echo e(__('Dashboard')); ?></span>
            <div class="col-12" style="overflow-x: auto">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 my-4 p-2 rounded">
                    <div class="text-center relative w-full px-4 py-2 bg-white shadow-lg dark:bg-gray-700">
                        <p class="text-2xl font-bold dark:text-white texto-azul">
                            <?php echo e($total_usuarios); ?>

                        </p>
                        <p class="text-sm" style="color:#212f3d">
                            <?php echo e(__('Users')); ?>

                        </p>
                        <span class="absolute p-4 rounded-full top-2 right-4">
                            <i class="icofont icofont-user-alt-5 texto-primero" style="font-size:2.2em;"></i>
                        </span>
                    </div>
                    <div class="text-center relative w-full px-4 py-2 bg-white shadow-lg dark:bg-gray-700">
                        <p class="text-2xl font-bold dark:text-white texto-azul">
                            <?php echo e($total_franquiciados); ?>

                        </p>
                        <p class="text-sm texto-primero">
                            <?php echo e(__('Franchisee')); ?>

                        </p>
                        <span class="absolute p-4 rounded-full top-2 right-4">
                            <i class="icofont icofont-user-male texto-primero" style="font-size:2.2em;"></i>
                        </span>
                    </div>
                    <div class="text-center relative w-full px-4 py-2 bg-white shadow-lg dark:bg-gray-700">
                        <p class="text-2xl font-bold dark:text-white texto-azul">
                            <?php echo e($total_maquinas_activas); ?>

                        </p>
                        <p class="text-sm" style="color:#212f3d">
                            <?php echo e(__('Machines Actives')); ?>

                        </p>
                        <span class="absolute p-4 rounded-full top-2 right-4">
                            <i class="icofont icofont-automation texto-primero" style="font-size:2.2em;"></i>
                        </span>
                    </div>
                    <div class="text-center relative w-full px-4 py-2 bg-white shadow-lg dark:bg-gray-700">
                        <p class="text-2xl font-bold dark:text-white texto-azul">
                            <?php echo e($total_maquinas_inactivas); ?>

                        </p>
                        <p class="text-sm" style="color:#212f3d">
                            <?php echo e(__('Machine Inantives')); ?>

                        </p>
                        <span class="absolute p-4 rounded-full top-2 right-4">
                            <i class="icofont icofont-settings-alt texto-primero" style="font-size:2.2em;"></i>
                        </span>
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 my-4 p-2 rounded">
                    <div class="w-full">
                        <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700">
                            <p class="text-sm font-semibold text-gray-700 border-b border-gray-200 w-max dark:text-white">
                                <?php echo e(__('Client')); ?>

                            </p>
                            <div class="flex items-end my-6 space-x-2">
                                <p class="text-5xl font-bold dark:text-white texto-primero">
                                    <?php echo e($total_usuarios); ?>

                                </p>
                                <span class="flex items-center text-xl font-bold text-green-500">
                                </span>
                            </div>
                            <div class="dark:text-white">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center justify-between pb-2 mb-2 text-sm border-b border-gray-200 sm:space-x-12">
                                        <p>
                                            <?php echo e($usu->name); ?>

                                        </p>
                                        <div class="flex items-end text-xs">
                                            <?php echo e($usu->telefono); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                    <div class="w-full">
                        <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700">
                            <p class="text-sm font-semibold text-gray-700 border-b border-gray-200 w-max dark:text-white">
                                <?php echo e(__('Franchisee')); ?>

                            </p>
                            <div class="flex items-end my-6 space-x-2">
                                <p class="text-5xl font-bold dark:text-white texto-primero">
                                    <?php echo e($total_franquiciados); ?>

                                </p>
                                <span class="flex items-center text-xl font-bold text-green-500">
                                </span>
                            </div>
                            <div class="dark:text-white">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_franquiciados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center justify-between pb-2 mb-2 text-sm border-b border-gray-200 sm:space-x-12">
                                        <p>
                                            <?php echo e($fran->name); ?>

                                        </p>
                                        <div class="flex items-end text-xs">
                                            <?php echo e($fran->telefono); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                    <div class="w-full">
                        <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700">
                            <p class="text-sm font-semibold text-gray-700 border-b border-gray-200 w-max dark:text-white">
                                <?php echo e(__('Machines')); ?>

                            </p>
                            <div class="flex items-end my-6 space-x-2">
                                <p class="text-5xl font-bold dark:text-white texto-primero">
                                    <?php echo e($total_maquinas_activas + $total_maquinas_inactivas); ?>

                                </p>
                                <span class="flex items-center text-xl font-bold text-green-500">
                                </span>
                            </div>
                            <div class="dark:text-white">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_maquinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center justify-between pb-2 mb-2 text-sm border-b border-gray-200 sm:space-x-12">
                                        <p>
                                            <?php echo e($maq->id_maquina); ?>

                                        </p>
                                        <div class="flex items-end text-xs">
                                            <?php echo e($maq->numero_salidas); ?>

                                            <?php echo e(__('Outpus')); ?>

                                            <!--[if BLOCK]><![endif]--><?php if($maq->maquina_registrada == 1): ?>
                                                <span class="texto-verde ml-2">(Active)</span>
                                            <?php else: ?>
                                                <span class="texto-rojo ml-2">(Inactive)</span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e86184e23470ccb5b55720dccb4a286)): ?>
<?php $attributes = $__attributesOriginal8e86184e23470ccb5b55720dccb4a286; ?>
<?php unset($__attributesOriginal8e86184e23470ccb5b55720dccb4a286); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e86184e23470ccb5b55720dccb4a286)): ?>
<?php $component = $__componentOriginal8e86184e23470ccb5b55720dccb4a286; ?>
<?php unset($__componentOriginal8e86184e23470ccb5b55720dccb4a286); ?>
<?php endif; ?>
</div><?php /**PATH /var/www/vhosts/multifactor1.com/httpdocs/resources/views/livewire/admin/dashboard-admin.blade.php ENDPATH**/ ?>