<?php

use App\Events\MessageSent;
use Livewire\Attributes\On;
use Livewire\Volt\Component;
use App\Models\Maquina;
use App\Models\MaquinasSalida;
use App\Models\User;

?>

<div class="container">
    <span class="text-2xl font-semi-bold leading-normal">Dashboard</span>
    <div class="col-12" style="overflow-x: auto">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 my-4 p-2 rounded">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-full">
                    <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700 rounded">
                        <!-- SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS MAQUINAS -->
                            <!--[if BLOCK]><![endif]--><?php if($maq->estatus_device == 1): ?>
                                <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                    <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                        <div class="flex flex-wrap items-center justify-between">
                                            <div class="flex items-center flex-1 w-0">
                                                <span class="flex p-2 rounded-lg dark:bg-black fondo-naranja">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                        <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                        </path>
                                                    </svg>
                                                </span>
                                                <p class="ml-3 font-medium">
                                                    <span class="md:inline texto-primary">
                                                        Device waiting for update.
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                    
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!-- FIN DE CAMBIO DE PARAMETROS -->
                        <div class="mb-4">
                            <div class="flex items-center justify-between mb-2">
                                <div class="flex items-center">
                                    <span class="relative p-2 fondo-primero rounded-xl">

                                    </span>
                                    <div class="flex flex-col">
                                        <span class="ml-2 font-bold texto-primero text-md dark:text-white">
                                            <?php echo e($maq->nombre); ?>

                                            <span class="ml-2 text-xs text-gray-500 dark:text-white">
                                                (<?php echo e("ID ".$maq->id_maquina); ?>)
                                            </span>
                                        </span>
                                        <span class="ml-2 text-sm text-gray-500 dark:text-white">
                                            <!--[if BLOCK]><![endif]--><?php if($maq->dia_id <> ''): ?>
                                                <?php echo e($maq->reloj." - ".$maq->maquina_dia->dias); ?>

                                            <?php else: ?>
                                                <?php echo e($maq->reloj); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                        <a wire:click="edit_name_maquina(<?php echo e($maq); ?>)" class="cursor-pointer" title="Name nachine edit"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                    </button>
                                </div>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php if(isset($maquinas_salidas)): ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>




    <div class="w-full h-full bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded overflow-auto flex flex-col px-2 py-4">
        <div x-ref="chatBox" class="flex-1 p-4 text-sm flex flex-col gap-y-1">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><span class="text-indigo-600"><?php echo e($message->name); ?>:</span> <span class="dark:text-white"><?php echo e($message->email); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
            <form wire:submit.prevent="addMessage" class="flex gap-2">
                <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['wire:model' => 'message','xRef' => 'messageInput','name' => 'message','id' => 'message','class' => 'block w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'message','x-ref' => 'messageInput','name' => 'message','id' => 'message','class' => 'block w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    Send
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
            </form>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\multifactor1-new\resources\views\livewire/user/monitoreo.blade.php ENDPATH**/ ?>