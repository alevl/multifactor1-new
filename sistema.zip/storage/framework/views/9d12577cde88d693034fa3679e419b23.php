<div>
    <?php if (isset($component)) { $__componentOriginal469697c8a3c244cba6b653458854f352 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal469697c8a3c244cba6b653458854f352 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\MenuFranquicia::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.menu-franquicia'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\MenuFranquicia::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="container" wire:poll>
            <span class="text-2xl font-semi-bold leading-normal"><?php echo e(__('Dashboard')); ?></span>
            <div class="col-12" style="overflow-x: auto">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 my-4 p-2 rounded">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if($maq->modelo == 2): ?> <!-- MODELO MECAELECT --> 
                            <div class="w-full">
                                <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700 rounded">
                                    <!-- SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS MAQUINAS -->
                                    <!--[if BLOCK]><![endif]--><?php if($maq->estatus_device == 1): ?>
                                        <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                            <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                <div class="flex flex-wrap items-center justify-between">
                                                    <div class="flex items-center flex-1 w-0">
                                                        <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                </path>
                                                            </svg>
                                                        </span>
                                                        <p class="ml-3 font-medium">
                                                            <span class="md:inline texto-primary">
                                                                <?php echo e(__('Waiting for device date update.')); ?>

                                                            </span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php if($maq->estatus_ajuste == 1): ?>
                                        <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                            <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                <div class="flex flex-wrap items-center justify-between">
                                                    <div class="flex items-center flex-1 w-0">
                                                        <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                </path>
                                                            </svg>
                                                        </span>
                                                        <p class="ml-3 font-medium">
                                                            <span class="md:inline texto-primary">
                                                                <?php echo e(__('Waiting for temperature update.')); ?>

                                                            </span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php if($maq->estatus_frecuencia == 1): ?>
                                        <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                            <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                <div class="flex flex-wrap items-center justify-between">
                                                    <div class="flex items-center flex-1 w-0">
                                                        <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                </path>
                                                            </svg>
                                                        </span>
                                                        <p class="ml-3 font-medium">
                                                            <span class="md:inline texto-primary">
                                                                <?php echo e(__('Waiting for defrost update.')); ?>

                                                            </span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!-- FIN DE CAMBIO DE PARAMETROS -->
                                    <!--ALERTAS DEL SISTEMA-->
                                    <!--[if BLOCK]><![endif]--><?php if($maq->estatus_estado_id == 0): ?>
                                        <div class="bg-yellow-200 dark:bg-gray-800 mt-0 mb-6">
                                            <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                <div class="flex flex-wrap items-center justify-between">
                                                    <div class="flex items-center flex-1 w-0">
                                                        <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                </path>
                                                            </svg>
                                                        </span>
                                                        <p class="ml-3 font-medium">
                                                            <span class="md:inline texto-primary">
                                                                <?php echo e(__('System Disabled; Only manual output works.')); ?>

                                                            </span>
                                                        </p>
                                                        <div class="px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6 fondo-primary">
                                                            <a wire:click="$dispatch('sistema1', <?php echo e($maq->id); ?>)" class="cursor-pointer inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-500 sm:ml-3 sm:w-auto" style="margin:auto">Habilitar</a>
                                                        </div>            
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--FIN ALERTAS DEL SISTEMA-->
                                    <div class="mb-4">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center">
                                                <div class="flex flex-col">
                                                    <span class="ml-2 font-bold texto-primero text-md dark:text-white">
                                                        <?php echo e($maq->nombre); ?>

                                                        <span class="ml-2 text-xs text-gray-500 dark:text-white">
                                                            (<?php echo e("ID ".$maq->id_maquina); ?>)
                                                        </span>
                                                    </span>
                                                    <!--[if BLOCK]><![endif]--><?php if($maq->estatus_estado_id <> 0): ?>
                                                        <span class="text-sm text-gray-500 dark:text-white">
                                                            <span class="flex items-center px-2 py-1 text-xs font-semibold text-green-600 ">
                                                                Sistema Habilitado
                                                                    <span class="ml-2">
                                                                        <a wire:click="$dispatch('sistema2', <?php echo e($maq->id); ?>)" class="cursor-pointer p-1 rounded" style="color: #e74c3c;background-color: #fadbd8; font-size:0.8em">Deshabilitar</a>
                                                                    </span>
                                                                </a>
                                                            </span>
                                                        </span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                            <div class="flex items-center">
                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                    <a wire:click="edit_parametros(<?php echo e($maq); ?>)" class="cursor-pointer" title="Name nachine edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                </button>
                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                    <a wire:click="edit_name_maquina(<?php echo e($maq); ?>)" class="cursor-pointer" title="<?php echo e(__('Name nachine edit')); ?>"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                </button>
                                            </div>
                                        </div>

                                        <!--[if BLOCK]><![endif]--><?php if($maq->encendido_permanente == 1): ?>
                                            <div class="flex items-center">
                                                <label class="inline-flex items-center mb-5 cursor-pointer">
                                                    <input type="checkbox" value="" class="sr-only peer" checked wire:click="encendido_permanente_no(<?php echo e($maq->id); ?>)">
                                                    <div class="relative w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                                                    <span class="ms-3 text-gray-900 dark:text-gray-300" style="font-size: 0.8em"><?php echo e(__('Permanent ON')); ?></span>
                                                </label>
                                            </div>
                                        <?php else: ?>
                                            <div class="flex items-center">
                                                <label class="inline-flex items-center mb-5 cursor-pointer">
                                                    <input type="checkbox" value="" class="sr-only peer" wire:click="encendido_permanente_si(<?php echo e($maq->id); ?>)">
                                                    <div class="relative w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                                                    <span class="ms-3 text-gray-900 dark:text-gray-300" style="font-size: 0.8em"><?php echo e(__('Permanent ON')); ?></span>
                                                </label>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-2 p-2 rounded" style="margin-top: -10px">
                                            <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                <div class="flex items-center text-xs dark:text-white text-center">
                                                    <img src="<?php echo e(asset('storage/sistema/icono-tiempo.png')); ?>" class="mr-1" style="width: 25px" />
                                                    <?php echo e(__('Device Clock')); ?>

                                                </div>
                                                <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                    <!--[if BLOCK]><![endif]--><?php if($maq->dia_id <> ''): ?>
                                                        <?php echo e($maq->maquina_dia->dias.", ".$maq->reloj); ?>

                                                    <?php else: ?>
                                                        <?php echo e($maq->reloj); ?>

                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                            <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                <div class="flex items-center text-xs dark:text-white text-center">
                                                    <img src="<?php echo e(asset('storage/sistema/icono-horario.png')); ?>" class="mr-1" style="width: 25px" />
                                                    <?php echo e(__('Next Thaw')); ?>

                                                </div>
                                                <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                    <?php $swn = 1; ?>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas_salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val_sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <!--[if BLOCK]><![endif]--><?php if($val_sal->salida == 2 and $val_sal->id_maquina == $maq->id_maquina and ($val_sal->frecuencia_solicitado == 0 or $val_sal->duracion_solicitado == 0)): ?>
                                                            <?php $swn = 0; ?>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->							
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            
                                                    <!--[if BLOCK]><![endif]--><?php if($maq->deshielo == 1): ?>
                                                        <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                                <?php echo e(__('Defrost OFF')); ?>

                                                            </div>
                                                    <?php else: ?>
                                                        <!--[if BLOCK]><![endif]--><?php if($swn == 0): ?>
                                                            <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                                <?php echo e(__('Disabled')); ?>

                                                            </div>
                                                        <?php else: ?>
                                                            <?php echo e($maq->deshielo); ?>

                                                            <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                                <?php echo e(__('Defrost ON')); ?>

                                                            </div>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                            <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                <div class="flex items-center text-xs dark:text-white text-center">
                                                    <img src="<?php echo e(asset('storage/sistema/icono-temperatura.png')); ?>" class="mr-1" style="width: 27px" />
                                                    <?php echo e(__('Temperature')); ?>

                                                </div>
                                                <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                    <?php echo e($maq->temperatura." °C"); ?>

                                                    <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                        <?php echo e(date("d/m/Y", strtotime($maq->updated_at))." / ".date("H:i:s", strtotime($maq->updated_at))); ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                <div class="flex items-center text-xs dark:text-white text-center">
                                                    <img src="<?php echo e(asset('storage/sistema/icono-humedad.png')); ?>" class="mr-1" style="width: 27px" />
                                                    <?php echo e(__('Humidity')); ?>

                                                </div>
                                                <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                    <?php echo e($maq->humedad." %"); ?>

                                                    <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                        <?php echo e(date("d/m/Y", strtotime($maq->updated_at))." / ".date("H:i:s", strtotime($maq->updated_at))); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="relative w-full px-4 py-6 dark:bg-gray-700 rounded fondo-amarillo">
                                            <div class="mb-2">
                                                <div class="flex items-center justify-between mb-2">
                                                    <div class="flex items-center">
                                                        <div class="flex flex-col">
                                                            <span class="ml-2 font-bold texto-primero text-md dark:text-white">
                                                                <?php echo e(__('Ouputs')); ?>

                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas_salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <!--[if BLOCK]><![endif]--><?php if($sal->maquina_id == $maq->id): ?>
                                                    <!-- SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS SALIDAS -->
                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_point == 1): ?>
                                                        <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                                            <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                                <div class="flex flex-wrap items-center justify-between">
                                                                    <div class="flex items-center flex-1 w-0">
                                                                        <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                                <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                                </path>
                                                                            </svg>
                                                                        </span>
                                                                        <p class="ml-3 font-medium">
                                                                            <span class="md:inline texto-primary">
                                                                                <?php echo e(__('Waiting for temperature range update')); ?>

                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <!-- FIN SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS SALIDAS -->
                                                    <!--[if BLOCK]><![endif]--><?php if($sal->salida == 1): ?>
                                                        <div class="flex items-center justify-between mb-2 fondo-gris rounded p-2">
                                                            <div class="flex items-center">
                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                        <?php echo e(__('OFF')); ?>

                                                                    </div>
                                                                <?php else: ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1): ?>
                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                            <?php echo e(__('ON')); ?>

                                                                        </div>                                                                
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <div class="flex flex-col">
                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                        <?php echo e(__('Temperature Range')); ?>

                                                                    </span>
                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                        Set Point 1: <span style="font-weight:bold"><?php echo e($sal->point1."°C"); ?></span> <span>Set Point 2:</span> <span style="font-weight:bold"><?php echo e($sal->point2."°C"); ?>

                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="flex items-center">
                                                            </div>
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <!--[if BLOCK]><![endif]--><?php if($sal->salida == 2): ?>
                                                        <div class="flex items-center justify-between mb-2 fondo-gris rounded p-2">
                                                            <div class="flex items-center">
                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                        <?php echo e(__('OFF')); ?>

                                                                    </div>
                                                                <?php else: ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2): ?>
                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                            <?php echo e(__('ON')); ?>

                                                                        </div>                                                                
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <div class="flex flex-col">
                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                        <?php echo e(__('Defrost parameters')); ?>

                                                                    </span>
                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                        Frecuencia: <span style="font-weight:bold"><?php echo e("Cada ".$sal->mostrar_frecuencia." horas"); ?></span>
                                                                            <br> 
                                                                        Duración: <span style="font-weight:bold"><?php echo e($sal->mostrar_duracion." minutos"); ?></span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="flex items-center">
                                                            </div>
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <!--[if BLOCK]><![endif]--><?php if($sal->salida == 3): ?>
                                                        <div class="flex items-center justify-between mb-2 fondo-gris rounded p-2">
                                                            <div class="flex items-center">
                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                        <?php echo e(__('OFF')); ?>

                                                                    </div>
                                                                <?php else: ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 4): ?>
                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                            <?php echo e(__('ON')); ?>

                                                                        </div>                                                                
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <div class="flex flex-col">
                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                        <?php echo e(__('Manual Output')); ?>

                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="flex items-center">
                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0 and $maq->estatus_sistema == 0 ): ?>
                                                                    <a wire:click="update_salida3(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-green-600 hover:bg-green-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                        <?php echo e(__('ON')); ?>

                                                                    </a>
                                                                <?php else: ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if(($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 4) and $maq->estatus_sistema == 0 ): ?>
                                                                        <a wire:click="update_salida3(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-red-600 hover:bg-red-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                            <?php echo e(__('OFF')); ?>

                                                                        </a>
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php if($maq->modelo == 3): ?> <!-- MODELO MULTIFACTOR (NUEVAS) --> 
                                <div class="w-full">
                                    <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700 rounded">
                                        <!-- SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS MAQUINAS -->
                                        <!--[if BLOCK]><![endif]--><?php if($maq->estatus_device == 1): ?>
                                            <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                                <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                    <div class="flex flex-wrap items-center justify-between">
                                                        <div class="flex items-center flex-1 w-0">
                                                            <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                    <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                    </path>
                                                                </svg>
                                                            </span>
                                                            <p class="ml-3 font-medium">
                                                                <span class="md:inline texto-primary">
                                                                    <?php echo e(__('Waiting for device date update.')); ?>

                                                                </span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($maq->estatus_ajuste == 1): ?>
                                            <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                                <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                    <div class="flex flex-wrap items-center justify-between">
                                                        <div class="flex items-center flex-1 w-0">
                                                            <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                    <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                    </path>
                                                                </svg>
                                                            </span>
                                                            <p class="ml-3 font-medium">
                                                                <span class="md:inline texto-primary">
                                                                    <?php echo e(__('Waiting for temperature update.')); ?>

                                                                </span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($maq->estatus_ajuste_hum == 1): ?>
                                            <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                                <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                    <div class="flex flex-wrap items-center justify-between">
                                                        <div class="flex items-center flex-1 w-0">
                                                            <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                    <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                    </path>
                                                                </svg>
                                                            </span>
                                                            <p class="ml-3 font-medium">
                                                                <span class="md:inline texto-primary">
                                                                    <?php echo e(__('Waiting for humidity update.')); ?>

                                                                </span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($maq->estatus_frecuencia == 1): ?>
                                            <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                                <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                    <div class="flex flex-wrap items-center justify-between">
                                                        <div class="flex items-center flex-1 w-0">
                                                            <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                    <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                    </path>
                                                                </svg>
                                                            </span>
                                                            <p class="ml-3 font-medium">
                                                                <span class="md:inline texto-primary">
                                                                    <?php echo e(__('Waiting for defrost update.')); ?>

                                                                </span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!-- FIN DE CAMBIO DE PARAMETROS -->
                                        <!--ALERTAS DEL SISTEMA-->
                                        <!--[if BLOCK]><![endif]--><?php if($maq->estatus_estado_id == 0): ?>
                                            <div class="bg-yellow-200 dark:bg-gray-800 mt-0 mb-6">
                                                <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                    <div class="flex flex-wrap items-center justify-between">
                                                        <div class="flex items-center flex-1 w-0">
                                                            <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                    <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                    </path>
                                                                </svg>
                                                            </span>
                                                            <p class="ml-3 font-medium">
                                                                <span class="md:inline texto-primary">
                                                                    <?php echo e(__('System Disabled; Only manual output works.')); ?>

                                                                </span>
                                                            </p>
                                                            <div class="px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6 fondo-primary">
                                                                <a wire:click="$dispatch('sistema1', <?php echo e($maq->id); ?>)" class="cursor-pointer inline-flex w-full justify-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-500 sm:ml-3 sm:w-auto" style="margin:auto">Habilitar</a>
                                                            </div>            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--FIN ALERTAS DEL SISTEMA-->
                                        <div class="mb-4">
                                            <div class="flex items-center justify-between mb-2">
                                                <div class="flex items-center">
                                                    <div class="flex flex-col">
                                                        <span class="ml-2 font-bold texto-primero text-md dark:text-white">
                                                            <?php echo e($maq->nombre); ?>

                                                            <span class="ml-2 text-xs text-gray-500 dark:text-white">
                                                                (<?php echo e("ID ".$maq->id_maquina); ?>)
                                                            </span>
                                                        </span>
                                                        <!--[if BLOCK]><![endif]--><?php if($maq->estatus_estado_id <> 0): ?>
                                                            <span class="text-sm text-gray-500 dark:text-white">
                                                                <span class="flex items-center px-2 py-1 text-xs font-semibold text-green-600 ">
                                                                    Sistema Habilitado
                                                                        <span class="ml-2">
                                                                            <a wire:click="$dispatch('sistema2', <?php echo e($maq->id); ?>)" class="cursor-pointer p-1 rounded" style="color: #e74c3c;background-color: #fadbd8; font-size:0.8em">Deshabilitar</a>
                                                                        </span>
                                                                    </a>
                                                                </span>
                                                            </span>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                                <div class="flex items-center">
                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                        <a wire:click="edit_parametros_modelo3(<?php echo e($maq); ?>)" class="cursor-pointer" title="Name nachine edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                    </button>
                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                        <a wire:click="edit_name_maquina(<?php echo e($maq); ?>)" class="cursor-pointer" title="<?php echo e(__('Name nachine edit')); ?>"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                    </button>
                                                </div>
                                            </div>

                                            <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-2 p-2 rounded" style="margin-top: -10px">
                                                <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                    <div class="flex items-center text-xs dark:text-white text-center">
                                                        <img src="<?php echo e(asset('storage/sistema/icono-tiempo.png')); ?>" class="mr-1" style="width: 25px" />
                                                        <?php echo e(__('Device Clock')); ?>

                                                    </div>
                                                    <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                        <!--[if BLOCK]><![endif]--><?php if($maq->dia_id <> ''): ?>
                                                            <?php echo e($maq->maquina_dia->dias.", ".$maq->reloj); ?>

                                                        <?php else: ?>
                                                            <?php echo e($maq->reloj); ?>

                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-2 p-2 rounded" style="margin-top: -10px">
                                                <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                    <div class="flex items-center text-xs dark:text-white text-center">
                                                        <img src="<?php echo e(asset('storage/sistema/icono-temperatura.png')); ?>" class="mr-1" style="width: 27px" />
                                                        <?php echo e(__('Temperature')); ?>

                                                    </div>
                                                    <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                        <?php echo e(number_format($maq->temperatura,1)." °C"); ?>

                                                        <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                            <?php echo e(date("d/m/Y", strtotime($maq->updated_at))." / ".date("H:i:s", strtotime($maq->updated_at))); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                    <div class="flex items-center text-xs dark:text-white text-center">
                                                        <img src="<?php echo e(asset('storage/sistema/icono-humedad.png')); ?>" class="mr-1" style="width: 27px" />
                                                        <?php echo e(__('Humidity')); ?>

                                                    </div>
                                                    <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                        <?php echo e(number_format($maq->humedad, 1)." %"); ?>

                                                        <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                            <?php echo e(date("d/m/Y", strtotime($maq->updated_at))." / ".date("H:i:s", strtotime($maq->updated_at))); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="relative w-full px-2 py-2 dark:bg-gray-700 rounded fondo-amarillo mb-2">
                                                <div class="flex flex-col">
                                                    <span class="ml-2 font-bold texto-primero text-md dark:text-white">
                                                        <?php echo e(__('Factor de Correccion')); ?>

                                                    </span>
                                                </div>
                                                <div class="flex items-center justify-between mb-2 rounded p-2">
                                                    <div class="text-center rounded fondo-gris p-2">
                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                            <?php echo e(__('Temperatura')); ?>

                                                        </span>
                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                            <span style="font-weight:bold"><?php echo e(number_format($maq->ajuste_temperatura,1)."°C"); ?>

                                                        </span>
                                                    </div>
                                                    <br>
                                                    <div class="text-center rounded fondo-gris p-2">
                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                            <?php echo e(__('Humedad')); ?>

                                                        </span>
                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                            <span style="font-weight:bold"><?php echo e(number_format($maq->ajuste_humedad,1)."%"); ?>

                                                        </span>
                                                    </div>
                                                    <div class="flex items-center">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="relative w-full px-4 py-6 dark:bg-gray-700 rounded fondo-amarillo">
                                                <?php echo e("CHORIZO : ".$maq->chorizo); ?>

                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas_salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <!--[if BLOCK]><![endif]--><?php if($sal->maquina_id == $maq->id): ?>
                                                        <!-- SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS SALIDAS -->
                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_parametros == 1): ?>
                                                            <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                                                <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                                    <div class="flex flex-wrap items-center justify-between">
                                                                        <div class="flex items-center flex-1 w-0">
                                                                            <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                                    <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                                    </path>
                                                                                </svg>
                                                                            </span>
                                                                            <p class="ml-3 font-medium">
                                                                                <span class="md:inline texto-primary">
                                                                                    <?php echo e(__('Waiting update')); ?>

                                                                                </span>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <!-- FIN SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS SALIDAS -->

                                                        <!--[if BLOCK]><![endif]--><?php if($sal->salida == 1): ?>
                                                            <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 0): ?>
                                                                <div class="flex items-center justify-between mb-2">
                                                                    <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                        <?php echo e(__('Output 1 - Manual')); ?>

                                                                    </div>
                                                                    <div class="flex items-center">
                                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                                            <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                                <div class="flex items-center justify-between mb-2 fondo-gris rounded p-2">
                                                                    <div class="flex items-center">
                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                            <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                <?php echo e('OFF'); ?>

                                                                            </div>
                                                                        <?php else: ?>
                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                    <?php echo e('ON'); ?>

                                                                                </div>
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        <div class="flex flex-col">
                                                                            <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                <?php echo e(__('Manual Output')); ?>

                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="flex items-center">
                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0 and $maq->estatus_sistema == 0 ): ?>
                                                                            <a wire:click="update_salida_manual1(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-green-600 hover:bg-green-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                <?php echo e('ON'); ?>

                                                                            </a>
                                                                        <?php else: ?>
                                                                            <!--[if BLOCK]><![endif]--><?php if(($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 4) and $maq->estatus_sistema == 0 ): ?>
                                                                                <a wire:click="update_salida_manual1(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-red-600 hover:bg-red-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                    <?php echo e('OFF'); ?>

                                                                                </a>
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                    </div>
                                                                </div>
                                                            <?php else: ?>
                                                                <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 16): ?>
                                                                    <div class="flex items-center justify-between mb-2">
                                                                        <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                            <?php echo e(__('Output 1 - Temperatura')); ?>

                                                                        </div>
                                                                        <div class="flex items-center">
                                                                            <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                            </button>
<?php /*
                                                                            <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                            </button>
*/ ?>
                                                                            </div>
                                                                    </div>
                                                                    <div class="flex items-center justify-between mb-2 p-2">
                                                                        <div class="flex items-center">
                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                    <?php echo e('OFF'); ?>

                                                                                </div>
                                                                            <?php else: ?>
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                        <?php echo e('ON'); ?>

                                                                                    </div>
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        </div>
                                                                        <div class="flex items-center">
                                                                            <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                    <?php echo e(__('Mínima')); ?>

                                                                                </span>
                                                                                <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro1."°C"); ?>

                                                                                </span>
                                                                            </div>
                                                                            <br>
                                                                            <div class="text-center fondo-gris rounded p-2">
                                                                                <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                    <?php echo e(__('Máxima')); ?>

                                                                                </span>
                                                                                <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro2."°C"); ?>

                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="flex items-center">
                                                                        </div>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 32): ?>
                                                                        <div class="flex items-center justify-between mb-2">
                                                                            <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                    <?php echo e(__('Output 1 - Humedad')); ?>

                                                                            </div>
                                                                            <div class="flex items-center">
                                                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                    <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                </button>
<?php /*
                                                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                    <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                </button>
*/ ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="flex items-center justify-between mb-2 p-2">
                                                                            <div class="flex items-center">
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                        <?php echo e('OFF'); ?>

                                                                                    </div>
                                                                                <?php else: ?>
                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                            <?php echo e('ON'); ?>

                                                                                        </div>
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            </div>
                                                                            <div class="flex items-center">
                                                                                <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                        <?php echo e(__('Mínima')); ?>

                                                                                    </span>
                                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                        <span style="font-weight:bold"><?php echo e($sal->parametro1."%"); ?>

                                                                                    </span>
                                                                                </div>
                                                                                <br>
                                                                                <div class="text-center fondo-gris rounded p-2">
                                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                        <?php echo e(__('Máxima')); ?>

                                                                                    </span>
                                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                        <span style="font-weight:bold"><?php echo e($sal->parametro2."%"); ?>

                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="flex items-center">
                                                                            </div>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 48): ?>
                                                                            <div class="flex items-center justify-between mb-2">
                                                                                <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                    <?php echo e(__('Output 1 - Horario')); ?>

                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                        <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                    </button>
<?php /*
                                                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                        <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                    </button>
*/ ?>
                                                                                </div>
                                                                            </div>
                                                                            <div class="flex items-center justify-between mb-2 p-2">
                                                                                <div class="flex items-center">
                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                            <?php echo e('OFF'); ?>

                                                                                        </div>
                                                                                    <?php else: ?>
                                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                            <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                <?php echo e('ON'); ?>

                                                                                            </div>
                                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                    <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                            <?php echo e(__('Hora ON')); ?>

                                                                                        </span>
                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro1); ?>

                                                                                        </span>
                                                                                    </div>
                                                                                    <div class="text-center fondo-gris rounded p-2">
                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                            <?php echo e(__('Hora OFF')); ?>

                                                                                        </span>
                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro2); ?>

                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 64): ?>
                                                                                <div class="flex items-center justify-between mb-2">
                                                                                    <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                        <?php echo e(__('Output 1 - Cíclico')); ?>

                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                            <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                        </button>
<?php /*
                                                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                            <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                        </button>
*/ ?>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flex items-center justify-between mb-0 p-2">
                                                                                    <div class="flex items-center">
                                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                            <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                <?php echo e('OFF'); ?>

                                                                                            </div>
                                                                                        <?php else: ?>
                                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                    <?php echo e('ON'); ?>

                                                                                                </div>
                                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-2 p-2 rounded" style="margin-top: -10px">
                                                                                            <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                                <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                    <?php echo e(__('Frecuencia')); ?>

                                                                                                </span>
                                                                                                <br/>
                                                                                                <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro1." hora(s)"); ?></span>
                                                                                                </span>
                                                                                            </div>
                                                                                            <div class="text-center fondo-gris rounded p-2">
                                                                                                <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                    <?php echo e(__('Duración ')); ?>

                                                                                                    </br>
                                                                                                </span>
                                                                                                <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro2." minuto(s)"); ?></span>
                                                                                                </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="items-center w-full text-center fondo-gris rounded p-2 mb-2">
                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro3." hora(s)"); ?></span>
                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro4." minuto(s)"); ?></span>
                                                                                </div>
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php else: ?>
                                                            <!--[if BLOCK]><![endif]--><?php if($sal->salida == 2): ?>
                                                                <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 0): ?>
                                                                    <div class="flex items-center justify-between mb-2">
                                                                        <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                            <?php echo e(__('Output 2 - Manual')); ?>

                                                                        </div>
                                                                        <div class="flex items-center">
                                                                            <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                    <div class="flex items-center justify-between mb-2 fondo-gris rounded p-2">
                                                                        <div class="flex items-center">
                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                    <?php echo e('OFF'); ?>

                                                                                </div>
                                                                            <?php else: ?>
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                        <?php echo e('ON'); ?>

                                                                                    </div>
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            <div class="flex flex-col">
                                                                                <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                    <?php echo e(__('Manual Output')); ?>

                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="flex items-center">
                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0 and $maq->estatus_sistema == 0 ): ?>
                                                                                <a wire:click="update_salida_manual2(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-green-600 hover:bg-green-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                    <?php echo e('ON'); ?>

                                                                                </a>
                                                                            <?php else: ?>
                                                                                <!--[if BLOCK]><![endif]--><?php if(($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2) and $maq->estatus_sistema == 0 ): ?>
                                                                                    <a wire:click="update_salida_manual2(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-red-600 hover:bg-red-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                        <?php echo e('OFF'); ?>

                                                                                    </a>
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        </div>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 16): ?>
                                                                        <div class="flex items-center justify-between mb-2">
                                                                            <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                <?php echo e(__('Output 2 - Temperatura')); ?>

                                                                            </div>
                                                                            <div class="flex items-center">
                                                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                    <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                </button>
<?php /*
                                                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                    <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                </button>
*/ ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="flex items-center justify-between mb-2 p-2">
                                                                            <div class="flex items-center">
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                        <?php echo e('OFF'); ?>

                                                                                    </div>
                                                                                <?php else: ?>
                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                            <?php echo e('ON'); ?>

                                                                                        </div>
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            </div>
                                                                            <div class="flex items-center">
                                                                                <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                        <?php echo e(__('Mínima')); ?>

                                                                                    </span>
                                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                        <span style="font-weight:bold"><?php echo e($sal->parametro1."°C"); ?>

                                                                                    </span>
                                                                                </div>
                                                                                <br>
                                                                                <div class="text-center fondo-gris rounded p-2">
                                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                        <?php echo e(__('Máxima')); ?>

                                                                                    </span>
                                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                        <span style="font-weight:bold"><?php echo e($sal->parametro2."°C"); ?>

                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="flex items-center">
                                                                            </div>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 32): ?>
                                                                            <div class="flex items-center justify-between mb-2">
                                                                                <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                        <?php echo e(__('Output 2 - Humedad')); ?>

                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                        <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                    </button>
<?php /*
                                                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                        <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                    </button>
*/ ?>
                                                                                </div>
                                                                            </div>
                                                                            <div class="flex items-center justify-between mb-2 p-2">
                                                                                <div class="flex items-center">
                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                            <?php echo e('OFF'); ?>

                                                                                        </div>
                                                                                    <?php else: ?>
                                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                            <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                <?php echo e('ON'); ?>

                                                                                            </div>
                                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                    <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                            <?php echo e(__('Mínima')); ?>

                                                                                        </span>
                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro1."%"); ?>

                                                                                        </span>
                                                                                    </div>
                                                                                    <br>
                                                                                    <div class="text-center fondo-gris rounded p-2">
                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                            <?php echo e(__('Máxima')); ?>

                                                                                        </span>
                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro2."%"); ?>

                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 48): ?>
                                                                                <div class="flex items-center justify-between mb-2">
                                                                                    <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                        <?php echo e(__('Output 2 - Horario')); ?>

                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                            <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                        </button>
<?php /*
                                                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                            <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                        </button>
*/ ?>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flex items-center justify-between mb-2 p-2">
                                                                                    <div class="flex items-center">
                                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                            <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                <?php echo e('OFF'); ?>

                                                                                            </div>
                                                                                        <?php else: ?>
                                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                    <?php echo e('ON'); ?>

                                                                                                </div>
                                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                        <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                            <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                <?php echo e(__('Hora ON')); ?>

                                                                                            </span>
                                                                                            <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                <span style="font-weight:bold"><?php echo e($sal->parametro1); ?>

                                                                                            </span>
                                                                                        </div>
                                                                                        <div class="text-center fondo-gris rounded p-2">
                                                                                            <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                <?php echo e(__('Hora OFF')); ?>

                                                                                            </span>
                                                                                            <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                <span style="font-weight:bold"><?php echo e($sal->parametro2); ?>

                                                                                            </span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                    </div>
                                                                                </div>
                                                                            <?php else: ?>
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 64): ?>
                                                                                    <div class="flex items-center justify-between mb-2">
                                                                                        <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                            <?php echo e(__('Output 2 - Cíclico')); ?>

                                                                                        </div>
                                                                                        <div class="flex items-center">
                                                                                            <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                                <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                            </button>
<?php /*
                                                                                            <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                                <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                            </button>
*/ ?>
                                                                                            </div>
                                                                                    </div>
                                                                                    <div class="flex items-center justify-between mb-2 p-2">
                                                                                        <div class="flex items-center">
                                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                    <?php echo e('OFF'); ?>

                                                                                                </div>
                                                                                            <?php else: ?>
                                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                        <?php echo e('ON'); ?>

                                                                                                    </div>
                                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                        </div>
                                                                                        <div class="flex items-center">
                                                                                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-2 p-2 rounded" style="margin-top: -10px">
                                                                                                <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                        <?php echo e(__('Frecuencia')); ?>

                                                                                                    </span>
                                                                                                    <br/>
                                                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                        <span style="font-weight:bold"><?php echo e($sal->parametro1." hora(s)"); ?></span>
                                                                                                    </span>
                                                                                                </div>
                                                                                                <div class="text-center fondo-gris rounded p-2">
                                                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                        <?php echo e(__('Duración ')); ?>

                                                                                                        </br>
                                                                                                    </span>
                                                                                                    <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                        <span style="font-weight:bold"><?php echo e($sal->parametro2." minuto(s)"); ?></span>
                                                                                                    </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="flex items-center">
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <?php else: ?>
                                                                <!--[if BLOCK]><![endif]--><?php if($sal->salida == 3): ?>
                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 0): ?>
                                                                        <div class="flex items-center justify-between mb-2">
                                                                            <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                <?php echo e(__('Output 3 - Manual')); ?>

                                                                            </div>
                                                                            <div class="flex items-center">
                                                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                    <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                        <div class="flex items-center justify-between mb-2 fondo-gris rounded p-2">
                                                                            <div class="flex items-center">
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                        <?php echo e('OFF'); ?>

                                                                                    </div>
                                                                                <?php else: ?>
                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                            <?php echo e('ON'); ?>

                                                                                        </div>
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                <div class="flex flex-col">
                                                                                    <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                        <?php echo e(__('Manual Output')); ?>

                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="flex items-center">
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0 and $maq->estatus_sistema == 0 ): ?>
                                                                                    <a wire:click="update_salida_manual3(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-green-600 hover:bg-green-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                        <?php echo e('ON'); ?>

                                                                                    </a>
                                                                                <?php else: ?>
                                                                                    <!--[if BLOCK]><![endif]--><?php if(($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 4) and $maq->estatus_sistema == 0 ): ?>
                                                                                        <a wire:click="update_salida_manual3(<?php echo e($sal->maquina_id); ?>)" class="cursor-pointer font-medium rounded-lg text-xs bg-red-600 hover:bg-red-800 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                            <?php echo e('OFF'); ?>

                                                                                        </a>
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            </div>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 16): ?>
                                                                            <div class="flex items-center justify-between mb-2">
                                                                                <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                    <?php echo e(__('Output 3 - Temperatura')); ?>

                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                        <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                    </button>
<?php /*
                                                                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                        <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                    </button>
*/ ?>
                                                                                </div>
                                                                            </div>
                                                                            <div class="flex items-center justify-between mb-2 p-2">
                                                                                <div class="flex items-center">
                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                            <?php echo e('OFF'); ?>

                                                                                        </div>
                                                                                    <?php else: ?>
                                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                            <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                <?php echo e('ON'); ?>

                                                                                            </div>
                                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                    <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                            <?php echo e(__('Mínima')); ?>

                                                                                        </span>
                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro1."°C"); ?>

                                                                                        </span>
                                                                                    </div>
                                                                                    <br>
                                                                                    <div class="text-center fondo-gris rounded p-2">
                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                            <?php echo e(__('Máxima')); ?>

                                                                                        </span>
                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro2."°C"); ?>

                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flex items-center">
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 32): ?>
                                                                                <div class="flex items-center justify-between mb-2">
                                                                                    <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                            <?php echo e(__('Output 3 - Humedad')); ?>

                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                            <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                        </button>
<?php /*
                                                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                            <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                        </button>
*/ ?>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flex items-center justify-between mb-2 p-2">
                                                                                    <div class="flex items-center">
                                                                                        <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                            <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                <?php echo e('OFF'); ?>

                                                                                            </div>
                                                                                        <?php else: ?>
                                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                    <?php echo e('ON'); ?>

                                                                                                </div>
                                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                        <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                            <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                <?php echo e(__('Mínima')); ?>

                                                                                            </span>
                                                                                            <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                <span style="font-weight:bold"><?php echo e($sal->parametro1."%"); ?>

                                                                                            </span>
                                                                                        </div>
                                                                                        <br>
                                                                                        <div class="text-center fondo-gris rounded p-2">
                                                                                            <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                <?php echo e(__('Máxima')); ?>

                                                                                            </span>
                                                                                            <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                <span style="font-weight:bold"><?php echo e($sal->parametro2."%"); ?>

                                                                                            </span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="flex items-center">
                                                                                    </div>
                                                                                </div>
                                                                            <?php else: ?>
                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 48): ?>
                                                                                    <div class="flex items-center justify-between mb-2">
                                                                                        <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                            <?php echo e(__('Output 3 - Horario')); ?>

                                                                                        </div>
                                                                                        <div class="flex items-center">
                                                                                            <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                                <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                            </button>
<?php /*
                                                                                            <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                                <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                            </button>
*/ ?>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="flex items-center justify-between mb-2 p-2">
                                                                                        <div class="flex items-center">
                                                                                            <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                                <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                    <?php echo e('OFF'); ?>

                                                                                                </div>
                                                                                            <?php else: ?>
                                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                        <?php echo e('ON'); ?>

                                                                                                    </div>
                                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                        </div>
                                                                                        <div class="flex items-center">
                                                                                            <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                                <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                    <?php echo e(__('Hora ON')); ?>

                                                                                                </span>
                                                                                                <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro1); ?>

                                                                                                </span>
                                                                                            </div>
                                                                                            <div class="text-center fondo-gris rounded p-2">
                                                                                                <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                    <?php echo e(__('Hora OFF')); ?>

                                                                                                </span>
                                                                                                <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                    <span style="font-weight:bold"><?php echo e($sal->parametro2); ?>

                                                                                                </span>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="flex items-center">
                                                                                        </div>
                                                                                    </div>
                                                                                <?php else: ?>
                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->modo_salida == 64): ?>
                                                                                        <div class="flex items-center justify-between mb-2">
                                                                                            <div class="flex items-center font-bold texto-primero text-md dark:text-white">
                                                                                                <?php echo e(__('Output 3 - Cíclico')); ?>

                                                                                            </div>
                                                                                            <div class="flex items-center">
                                                                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                                    <a wire:click="edit_salidas_modelo3(<?php echo e($sal->maquina_id); ?>, <?php echo e($sal->salida); ?>)" class="cursor-pointer" title="Output edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                                                                </button>
 <?php /*
                                                                                                <button class="p-1 mr-0 text-sm text-gray-400">
                                                                                                    <a wire:click="correccion_salidas_modelo3({{ $sal->maquina_id }}, {{ $sal->salida }})" class="cursor-pointer" title="Factor de corrección"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                                                                </button>
*/ ?>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="flex items-center justify-between mb-2 p-2">
                                                                                            <div class="flex items-center">
                                                                                                <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0): ?>
                                                                                                    <div class="flex mr-2 font-medium rounded-lg text-xs bg-red-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                        <?php echo e('OFF'); ?>

                                                                                                    </div>
                                                                                                <?php else: ?>
                                                                                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 1 or $sal->estatus_estado_id == 2 or $sal->estatus_estado_id == 4): ?>
                                                                                                        <div class="flex mr-2 font-medium rounded-lg text-xs bg-green-600 text-white font-bold py-2 px-2 rounded" style="font-size:0.6em">
                                                                                                            <?php echo e('ON'); ?>

                                                                                                        </div>
                                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                            </div>
                                                                                            <div class="flex items-center">
                                                                                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-2 p-2 rounded" style="margin-top: -10px">
                                                                                                    <div class="text-center fondo-gris rounded p-2 mr-2">
                                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                            <?php echo e(__('Frecuencia')); ?>

                                                                                                        </span>
                                                                                                        <br/>
                                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro1." hora(s)"); ?></span>
                                                                                                        </span>
                                                                                                    </div>
                                                                                                    <div class="text-center fondo-gris rounded p-2">
                                                                                                        <span class="ml-1 font-bold text-sm dark:text-white texto-azul">
                                                                                                            <?php echo e(__('Duración ')); ?>

                                                                                                            </br>
                                                                                                        </span>
                                                                                                        <span class="ml-1 text-sm dark:text-white texto-azul">
                                                                                                            <span style="font-weight:bold"><?php echo e($sal->parametro2." minuto(s)"); ?></span>
                                                                                                        </span>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="flex items-center">
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->                                                            
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->                                                        
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <!--[if BLOCK]><![endif]--><?php if($maq->modelo == 4): ?> <!-- MODELO 4 MULTIFACTOR (NUEVAS) VOLTAJE --> 
                                    <div class="w-full">
                                        <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700 rounded">
                                            <!-- SOLICITUDES PENDIENTES DE CAMBIO DE PARAMETROS MAQUINAS -->
                                            <!--[if BLOCK]><![endif]--><?php if($maq->estatus_voltaje == 1): ?>
                                                <div class="bg-yellow-200 dark:bg-gray-800 mt-4 mb-6">
                                                    <div class="px-3 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                                                        <div class="flex flex-wrap items-center justify-between">
                                                            <div class="flex items-center flex-1 w-0">
                                                                <span class="flex p-2 rounded-lg dark:bg-black fondo-rojo">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="w-6 h-6 text-white" viewBox="0 0 1792 1792">
                                                                        <path d="M1024 1375v-190q0-14-9.5-23.5t-22.5-9.5h-192q-13 0-22.5 9.5t-9.5 23.5v190q0 14 9.5 23.5t22.5 9.5h192q13 0 22.5-9.5t9.5-23.5zm-2-374l18-459q0-12-10-19-13-11-24-11h-220q-11 0-24 11-10 7-10 21l17 457q0 10 10 16.5t24 6.5h185q14 0 23.5-6.5t10.5-16.5zm-14-934l768 1408q35 63-2 126-17 29-46.5 46t-63.5 17h-1536q-34 0-63.5-17t-46.5-46q-37-63-2-126l768-1408q17-31 47-49t65-18 65 18 47 49z">
                                                                        </path>
                                                                    </svg>
                                                                </span>
                                                                <p class="ml-3 font-medium">
                                                                    <span class="md:inline texto-primary">
                                                                        <?php echo e(__('Waiting for voltaje date update.')); ?>

                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <!-- FIN DE CAMBIO DE PARAMETROS -->
                                            <div class="mb-4">
                                                <div class="flex items-center justify-between mb-2">
                                                    <div class="flex items-center">
                                                        <div class="flex flex-col">
                                                            <span class="ml-2 font-bold texto-primero text-md dark:text-white">
                                                                <?php echo e($maq->nombre); ?>

                                                                <span class="ml-2 text-xs text-gray-500 dark:text-white">
                                                                    (<?php echo e("ID ".$maq->id_maquina); ?>)
                                                                </span>
                                                            </span>
                                                            <!--[if BLOCK]><![endif]--><?php if($maq->estatus_estado_id <> 0): ?>
                                                                <span class="text-sm text-gray-500 dark:text-white">
                                                                    <span class="flex items-center px-2 py-1 text-xs font-semibold text-green-600 ">
                                                                        Sistema Habilitado
                                                                            <span class="ml-2">
                                                                                <a wire:click="$dispatch('sistema2', <?php echo e($maq->id); ?>)" class="cursor-pointer p-1 rounded" style="color: #e74c3c;background-color: #fadbd8; font-size:0.8em">Deshabilitar</a>
                                                                            </span>
                                                                        </a>
                                                                    </span>
                                                                </span>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    </div>
                                                    <div class="flex items-center">
                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                            <a wire:click="edit_parametros_modelo4(<?php echo e($maq); ?>)" class="cursor-pointer" title="Name nachine edit"><i class="icofont icofont-gear texto-azul" style="font-size: 1em"></i></a>
                                                        </button>
                                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                                            <a wire:click="edit_name_maquina(<?php echo e($maq); ?>)" class="cursor-pointer" title="<?php echo e(__('Name nachine edit')); ?>"><i class="icofont icofont-edit-alt texto-azul" style="font-size: 1em"></i></a>
                                                        </button>
                                                    </div>
                                                </div>

                                                <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-2 p-2 rounded" style="margin-top: -10px">
                                                    <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                        <div class="flex items-center text-xl dark:text-white text-center">
                                                            <img src="<?php echo e(asset('storage/sistema/voltaje.png')); ?>" class="mr-1" style="width: 25px" />
                                                            <?php echo e(__('Voltaje')); ?>

                                                        </div>
                                                        <div class="text-xl text-yellow-400 font-bold dark:text-gray-200">
                                                            <?php echo e(number_format($maq->voltaje,2)); ?>

                                                            <div class="w-auto p-0"><span class="text-white inline-block py-0 px-2 text-xs font-medium rounded-full">
                                                                <?php echo e(date("d/m/Y", strtotime($maq->updated_at))." / ".date("H:i:s", strtotime($maq->updated_at))); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                                        <div class="flex items-center text-xl dark:text-white text-center">
                                                            <img src="<?php echo e(asset('storage/sistema/voltaje.png')); ?>" class="mr-1" style="width: 25px" />
                                                            <?php echo e(__('Factor')); ?>

                                                        </div>
                                                        <div class="text-xl text-yellow-400 font-bold dark:text-gray-200">
                                                            <?php echo e(number_format($maq->factor_voltaje,2)); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginal8553a628af4fbf23b9fd1871c2b550f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-ancho','data' => ['wire:model' => 'open_parametros','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-ancho'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open_parametros','class' => 'w-full']); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    <?php echo e(__('Device Parameters')); ?>

                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('content', null, []); ?> 
                    <div class="items-center justify-between mb-2 border border-gray-400 p-2 rounded ">
                        <div class="flex items-center">
                            <span class="relative p-2 fondo-primero rounded-xl">
                            </span>
                            <span class="ml-2 font-bold texto-primero text-base dark:text-white">
                                <?php echo e(('Dispositivo')); ?>

                            </span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-2 my-0 p-2 rounded">
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Hour')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Hour')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="hora_reloj">
                                    <option value="">Seleccione...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($hora->id_hora); ?>"><?php echo e($hora->horas); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'hora_reloj']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'hora_reloj']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Minutes')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Minutes')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="minuto_reloj">
                                    <option value="">Seleccione...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_minutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minuto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($minuto->id_minuto); ?>"><?php echo e($minuto->minutos); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'minuto_reloj']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'minuto_reloj']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Day of the week')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Day of the week')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="dia_id">
                                    <option value="">Seleccione...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dia->id); ?>"><?php echo e($dia->dias); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'dia_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'dia_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_device','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_device','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                            <?php echo e(__('Send device data')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>    
                    </div>
                    <div class="items-center justify-between mb-2 border border-gray-400 p-2 rounded">
                        <div class="flex items-center">
                            <span class="relative p-2 fondo-primero rounded-xl">
                            </span>
                            <span class="ml-2 font-bold texto-primero text-base dark:text-white">
                                <?php echo e(__('Calibrate Temperature')); ?>

                            </span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-2 my-0 p-2 rounded">
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Sign')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Sign')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="signo_calibrar" >
                                    <option value="">Seleccione...</option>
                                    <option value="48">+</option>
                                    <option value="45">-</option>      
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'signo_calibrar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'signo_calibrar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Integer')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Integer')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="entero_calibrar" >
                                    <option value="">Seleccione...</option>
                                    <option value="48">0</option>
                                    <option value="49">1</option>
                                    <option value="50">2</option>
                                    <option value="51">3</option>
                                    <option value="52">4</option>
                                    <option value="53">5</option>
                                    <option value="54">6</option>
                                    <option value="55">7</option>
                                    <option value="56">8</option>
                                    <option value="57">9</option>
                                    </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'entero_calibrar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'entero_calibrar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Decimal')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Decimal')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="decimal_calibrar" >
                                    <option value="">Seleccione...</option>
                                    <option value="48">.0</option>
                                    <option value="49">.1</option>
                                    <option value="50">.2</option>
                                    <option value="51">.3</option>
                                    <option value="52">.4</option>
                                    <option value="53">.5</option>
                                    <option value="54">.6</option>
                                    <option value="55">.7</option>
                                    <option value="56">.8</option>
                                    <option value="57">.9</option>
                                    </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'decimal_calibrar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'decimal_calibrar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_calibrar','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_calibrar','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                            <?php echo e(__('Send Temperature Calibration')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                    </div>
                    <div class="items-center justify-between mb-2 border border-gray-400 p-2 rounded">
                        <div class="flex items-center">
                            <span class="relative p-2 fondo-primero rounded-xl">
                            </span>
                            <span class="ml-2 font-bold texto-primero text-base dark:text-white">
                                <?php echo e(__('Temperature Range')); ?>

                            </span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Set Point 1')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Set Point 1')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'setpoint','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'setpoint','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'setpoint']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'setpoint']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Set Point 2')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Set Point 2')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'setpoint2','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'setpoint2','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'setpoint2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'setpoint2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_point','wire:loading.attr' => 'disabled','class' => 'disabled:opacity-25 ml-2 mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_point','wire:loading.attr' => 'disabled','class' => 'disabled:opacity-25 ml-2 mb-4']); ?>
                            <?php echo e(__('Send Range Data')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                    </div>
                    <div class="items-center justify-between mb-2 border border-gray-400 p-2 rounded">
                        <div class="flex items-center">
                            <span class="relative p-2 fondo-primero rounded-xl">
                            </span>
                            <span class="ml-2 font-bold texto-primero text-base dark:text-white">
                                <?php echo e(__('Defrost parameters')); ?>

                            </span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-2 my-0 p-2 rounded">
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Frequency')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Frequency')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="frecuencia_deshielo" >
                                    <option value="">Seleccione...</option>
                                    <option value="1">1 Hora</option>
                                    <option value="2">2 Horas</option>
                                    <option value="3">3 Horas</option>
                                    <option value="4">4 Horas</option>
                                    <option value="5">5 Horas</option>
                                    <option value="6">6 Horas</option>
                                    <option value="7">7 Horas</option>
                                    <option value="8">8 Horas</option>
                                    <option value="9">9 Horas</option>
                                    <option value="10">10 Horas</option>
                                    <option value="12">12 Horas</option>
                                    <option value="14">14 Horas</option>
                                    <option value="16">16 Horas</option>
                                    <option value="18">18 Horas</option>
                                    <option value="20">20 Horas</option>
                                    <option value="22">22 Horas</option>
                                    <option value="24">24 Horas</option>
                                    </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'frecuencia_deshielo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'frecuencia_deshielo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Duration')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Duration')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="duracion_deshielo" >
                                    <option value="">Seleccione...</option>
                                    <option value="5">5 minutos</option>
                                    <option value="15">15 minutos</option>
                                    <option value="30">30 minutos</option>
                                    <option value="60">60 minutos</option>
                                    <option value="90">90 minutos</option>
                                    <option value="120">120 minutos</option>
                                    <option value="150">150 minutos</option>
                                    <option value="180">180 minutos</option>      
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'duracion_deshielo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'duracion_deshielo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_deshielo','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_deshielo','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                            <?php echo e(__('Send Defrost parameters')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala472d56bcd75879af470544a2a8043e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala472d56bcd75879af470544a2a8043e6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-secundario','data' => ['wire:click' => 'update_deshielo_disabled','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-secundario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_deshielo_disabled','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                            <?php echo e(__('Defrost disabled')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala472d56bcd75879af470544a2a8043e6)): ?>
<?php $attributes = $__attributesOriginala472d56bcd75879af470544a2a8043e6; ?>
<?php unset($__attributesOriginala472d56bcd75879af470544a2a8043e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala472d56bcd75879af470544a2a8043e6)): ?>
<?php $component = $__componentOriginala472d56bcd75879af470544a2a8043e6; ?>
<?php unset($__componentOriginala472d56bcd75879af470544a2a8043e6); ?>
<?php endif; ?>
                    </div>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('footer', null, []); ?> 
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => '$set(\'open_parametros\',false)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_parametros\',false)']); ?>
                        <?php echo e(__('Cancel')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1)): ?>
<?php $attributes = $__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1; ?>
<?php unset($__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8553a628af4fbf23b9fd1871c2b550f1)): ?>
<?php $component = $__componentOriginal8553a628af4fbf23b9fd1871c2b550f1; ?>
<?php unset($__componentOriginal8553a628af4fbf23b9fd1871c2b550f1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model' => 'open_parametros_modelo4','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open_parametros_modelo4','class' => 'w-full']); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    <?php echo e(__('Voltaje Parameters')); ?>

                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('content', null, []); ?> 
                    <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-4 my-0 p-2 rounded">
                        <div class="mb-2">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Introduzca el Factor de Corrección')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Introduzca el Factor de Corrección')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'factor_voltaje','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'factor_voltaje','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'factor_voltaje']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'factor_voltaje']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_factor_voltaje','wire:loading.attr' => 'disabled','class' => 'disabled:opacity-25 ml-2 mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_factor_voltaje','wire:loading.attr' => 'disabled','class' => 'disabled:opacity-25 ml-2 mb-4']); ?>
                        <?php echo e(__('Send Factor Voltaje')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('footer', null, []); ?> 
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => '$set(\'open_parametros_modelo4\',false)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_parametros_modelo4\',false)']); ?>
                        <?php echo e(__('Cancel')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $attributes = $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $component = $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal8553a628af4fbf23b9fd1871c2b550f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-ancho','data' => ['wire:model' => 'open_parametros_modelo3','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-ancho'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open_parametros_modelo3','class' => 'w-full']); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    <?php echo e(__('Device Parameters')); ?>

                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('content', null, []); ?> 
                    <div class="items-center justify-between mb-2 border border-gray-400 p-2 rounded ">
                        <div class="flex items-center">
                            <span class="relative p-2 fondo-primero rounded-xl">
                            </span>
                            <span class="ml-2 font-bold texto-primero text-base dark:text-white">
                                <?php echo e(('Dispositivo')); ?>

                            </span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-2 my-0 p-2 rounded">
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Hour')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Hour')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="hora_reloj">
                                    <option value="">Seleccione...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($hora->id_hora); ?>"><?php echo e($hora->horas); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'hora_reloj']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'hora_reloj']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Minutes')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Minutes')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="minuto_reloj">
                                    <option value="">Seleccione...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_minutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minuto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($minuto->id_minuto); ?>"><?php echo e($minuto->minutos); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'minuto_reloj']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'minuto_reloj']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Day of the week')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Day of the week')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="dia_id">
                                    <option value="">Seleccione...</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dia->id); ?>"><?php echo e($dia->dias); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'dia_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'dia_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_device','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_device','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                            <?php echo e(__('Send device data')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>    
                    </div>
                    <div class="items-center justify-between mb-2 border border-gray-400 p-2 rounded">
                        <div class="flex items-center">
                            <span class="relative p-2 fondo-primero rounded-xl">
                            </span>
                            <span class="ml-2 font-bold texto-primero text-base dark:text-white">
                                <?php echo e(__('Calibrate Temperature')); ?>

                            </span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-2 my-0 p-2 rounded">
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Sign')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Sign')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="signo_calibrar_temp" >
                                    <option value="">Seleccione...</option>
                                    <option value="0">+</option>
                                    <option value="1">-</option>      
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'signo_calibrar_temp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'signo_calibrar_temp']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Integer')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Integer')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="entero_calibrar_temp" >
                                    <option value="">Seleccione...</option>
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'entero_calibrar_temp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'entero_calibrar_temp']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Decimal')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Decimal')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="decimal_calibrar_temp" >
                                    <option value="">Seleccione...</option>
                                    <option value="0">.0</option>
                                    <option value="1">.1</option>
                                    <option value="2">.2</option>
                                    <option value="3">.3</option>
                                    <option value="4">.4</option>
                                    <option value="5">.5</option>
                                    <option value="6">.6</option>
                                    <option value="7">.7</option>
                                    <option value="8">.8</option>
                                    <option value="9">.9</option>
                                    </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'decimal_calibrar_temp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'decimal_calibrar_temp']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_calibrar_temp_modelo3','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar_temp_modelo3','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_calibrar_temp_modelo3','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar_temp_modelo3','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                            <?php echo e(__('Send Temperature Calibration')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                    </div>
                    <div class="items-center justify-between mb-2 border border-gray-400 p-2 rounded">
                        <div class="flex items-center">
                            <span class="relative p-2 fondo-primero rounded-xl">
                            </span>
                            <span class="ml-2 font-bold texto-primero text-base dark:text-white">
                                <?php echo e(__('Calibrate Humedad')); ?>

                            </span>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-2 my-0 p-2 rounded">
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Sign')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Sign')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="signo_calibrar_hum" >
                                    <option value="">Seleccione...</option>
                                    <option value="0">+</option>
                                    <option value="1">-</option>      
                                </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'signo_calibrar_hum']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'signo_calibrar_hum']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Integer')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Integer')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="entero_calibrar_hum" >
                                    <option value="">Seleccione...</option>
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'entero_calibrar_hum']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'entero_calibrar_hum']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                            <div class="mb-2">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Decimal')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Decimal')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="decimal_calibrar_hum" >
                                    <option value="">Seleccione...</option>
                                    <option value="0">.0</option>
                                    <option value="1">.1</option>
                                    <option value="2">.2</option>
                                    <option value="3">.3</option>
                                    <option value="4">.4</option>
                                    <option value="5">.5</option>
                                    <option value="6">.6</option>
                                    <option value="7">.7</option>
                                    <option value="8">.8</option>
                                    <option value="9">.9</option>
                                    </select>
                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'decimal_calibrar_hum']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'decimal_calibrar_hum']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_calibrar_hum','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_calibrar_hum','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                            <?php echo e(__('Send Humedad Calibration')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                    </div>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('footer', null, []); ?> 
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => '$set(\'open_parametros_modelo3\',false)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_parametros_modelo3\',false)']); ?>
                        <?php echo e(__('Cancel')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1)): ?>
<?php $attributes = $__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1; ?>
<?php unset($__attributesOriginal8553a628af4fbf23b9fd1871c2b550f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8553a628af4fbf23b9fd1871c2b550f1)): ?>
<?php $component = $__componentOriginal8553a628af4fbf23b9fd1871c2b550f1; ?>
<?php unset($__componentOriginal8553a628af4fbf23b9fd1871c2b550f1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model' => 'open_salidas_modelo3','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open_salidas_modelo3','class' => 'w-full']); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    <?php echo e(__('Config Output')); ?>

                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('content', null, []); ?> 
                    <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-4 my-0 p-2 rounded mt-4">
                        <div class="mb-4">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Cambiar la Salida a Modo')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Cambiar la Salida a Modo')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model.live="seleccion_modo_salida" >
                                <option value="">Seleccione</option>
                                <option value="0">Manual</option>
                                <option value="16">Temperatura</option>
                                <option value="32">Humedad</option>
                                <option value="48">Reloj</option>
                                <option value="64">Cíclico</option>
                            </select>
                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'usuario_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'usuario_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 0): ?>
                            <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                <?php echo e(__('Send Modo Salida Manual')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 16): ?>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                                    <div class="mb-2">
                                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Míninimo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Míninimo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'nuevo_parametro_temp1','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'nuevo_parametro_temp1','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_temp1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_temp1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mb-2">
                                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Máximo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Máximo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'nuevo_parametro_temp2','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'nuevo_parametro_temp2','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_temp2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_temp2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    </div>
                                </div>
                                <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                    <?php echo e(__('Send Modo Temperatura')); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                            <?php else: ?>
                                <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 32): ?>
                                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                                        <div class="mb-2">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Míninimo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Míninimo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'nuevo_parametro_hum1','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'nuevo_parametro_hum1','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_hum1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_hum1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                        </div>
                                        <div class="mb-2">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Máximo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Máximo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'nuevo_parametro_hum2','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'nuevo_parametro_hum2','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_hum2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_hum2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                        <?php echo e(__('Send Modo Humedad')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                                <?php else: ?>
                                    <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 48): ?>
                                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Hour')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Hour')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="nuevo_parametro_hora">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($hora->id_hora); ?>"><?php echo e($hora->horas); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_hora']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_hora']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Minutes')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Minutes')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="nuevo_parametro_minuto">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_minutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minuto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($minuto->id_minuto); ?>"><?php echo e($minuto->minutos); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_minuto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_minuto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Hour')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Hour')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="nuevo_parametro_hora2">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($hora->id_hora); ?>"><?php echo e($hora->horas); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_hora2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_hora2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Minutes')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Minutes')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="nuevo_parametro_minuto2">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_minutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minuto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($minuto->id_minuto); ?>"><?php echo e($minuto->minutos); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_minuto2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_minuto2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                            <?php echo e(__('Send Modo Reloj')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                                    <?php else: ?>
                                        <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 64): ?>
                                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                                                <div class="mb-2">
                                                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Frequency')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Frequency')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                    <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model.live="nuevo_parametro_frecuencia" >
                                                        <option value="">Seleccione...</option>
                                                        <option value="1">1 Hora</option>
                                                        <option value="2">2 Horas</option>
                                                        <option value="3">3 Horas</option>
                                                        <option value="4">4 Horas</option>
                                                        <option value="5">5 Horas</option>
                                                        <option value="6">6 Horas</option>
                                                        <option value="7">7 Horas</option>
                                                        <option value="8">8 Horas</option>
                                                        <option value="9">9 Horas</option>
                                                        <option value="10">10 Horas</option>
                                                        <option value="12">12 Horas</option>
                                                        <option value="14">14 Horas</option>
                                                        <option value="16">16 Horas</option>
                                                        <option value="18">18 Horas</option>
                                                        <option value="20">20 Horas</option>
                                                        <option value="22">22 Horas</option>
                                                        <option value="24">24 Horas</option>
                                                        </select>
                                                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_frecuencia']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_frecuencia']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                                </div>
                                                <div class="mb-2">
                                                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Duration')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Duration')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                    <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-500 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model.live="nuevo_parametro_duracion" >
                                                        <option value="">Seleccione...</option>
                                                        <option value="5">5 minutos</option>
                                                        <option value="15">15 minutos</option>
                                                        <option value="30">30 minutos</option>
                                                        <option value="60">60 minutos</option>
                                                        <option value="90">90 minutos</option>
                                                        <option value="120">120 minutos</option>
                                                        <option value="150">150 minutos</option>
                                                        <option value="180">180 minutos</option>      
                                                    </select>
                                                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'nuevo_parametro_duracion']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'nuevo_parametro_duracion']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                                <?php echo e(__('Send Modo Cíclico')); ?>

                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('footer', null, []); ?> 
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => '$set(\'open_salidas_modelo3\',false)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_salidas_modelo3\',false)']); ?>
                        <?php echo e(__('Cancel')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $attributes = $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $component = $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model' => 'open_correccion_salidas_modelo3','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open_correccion_salidas_modelo3','class' => 'w-full']); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    <?php echo e(__('Corrección Output')); ?>

                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('content', null, []); ?> 
                        <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 0): ?>
                            Salida Manual, no puede aplicar corrección
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 16): ?>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                                    <div class="mb-2">
                                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Mínima']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Mínima']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'corr_parametro_temp1','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'corr_parametro_temp1','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_temp1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_temp1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mb-2">
                                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Máxima']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Máxima']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'corr_parametro_temp2','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'corr_parametro_temp2','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_temp2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_temp2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    </div>
                                </div>
                                <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_correccion_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_correccion_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                    <?php echo e(__('Send Corrección Modo Temperatura')); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                            <?php else: ?>
                                <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida == 32): ?>
                                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                                        <div class="mb-2">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Mínima']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Mínima']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'corr_parametro_hum1','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'corr_parametro_hum1','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_hum1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_hum1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                        </div>
                                        <div class="mb-2">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => 'Máxima']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 'Máxima']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'corr_parametro_hum2','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'corr_parametro_hum2','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_hum2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_hum2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                        <?php echo e(__('Send Corrección Modo Humedad 1')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                                <?php else: ?>
                                    <!--[if BLOCK]><![endif]--><?php if($seleccion_modo_salida ==48): ?>
                                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 my-0 p-2 rounded">
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Hour')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Hour')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="corr_parametro_hora">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($hora->id_hora); ?>"><?php echo e($hora->horas); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_hora']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_hora']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Minutes')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Minutes')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="corr_parametro_minuto">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_minutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minuto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($minuto->id_minuto); ?>"><?php echo e($minuto->minutos); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_minuto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_minuto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Hour')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Hour')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="corr_parametro_hora2">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($hora->id_hora); ?>"><?php echo e($hora->horas); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_hora2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_hora2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                            <div class="mb-2">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Minutes')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Minutes')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <select class="w-full border-gray-300 focus:border-indigo-300 focus:ring-indigo-300 rounded-md border border-primary pl-2 pr-2 py-2.5 focus:outline-none sm:text-sm" wire:model="corr_parametro_minuto2">
                                                    <option value="">Seleccione...</option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lista_minutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minuto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($minuto->id_minuto); ?>"><?php echo e($minuto->minutos); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'corr_parametro_minuto2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'corr_parametro_minuto2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                        <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_correccion_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_correccion_modo_salida','wire:loading.attr' => 'disabled','wire:target' => 'update_calibrar','class' => 'mb-2 disabled:opacity-25 ml-2']); ?>
                                            <?php echo e(__('Send Corrección Modo Reloj')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('footer', null, []); ?> 
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => '$set(\'open_correccion_salidas_modelo3\',false)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_correccion_salidas_modelo3\',false)']); ?>
                        <?php echo e(__('Cancel')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $attributes = $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $component = $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model' => 'open_edit_maquina']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open_edit_maquina']); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    <?php echo e(__('Machine')); ?>

                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('content', null, []); ?> 
                    <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-4 my-0 p-2 rounded">
                        <div class="mb-2">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['value' => ''.e(__('Machine Name')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Machine Name')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.defer' => 'name_maquina','type' => 'text','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'name_maquina','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['for' => 'name_maquina']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name_maquina']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                        </div>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('footer', null, []); ?> 
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => '$set(\'open_edit_maquina\', false)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_edit_maquina\', false)']); ?>
                        <?php echo e(__('Cancel')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-primario','data' => ['wire:click' => 'update_maquina','wire:loading.attr' => 'disabled','class' => 'disabled:opacity-25 ml-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-primario'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'update_maquina','wire:loading.attr' => 'disabled','class' => 'disabled:opacity-25 ml-2']); ?>
                        <?php echo e(__('Update')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $attributes = $__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__attributesOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f)): ?>
<?php $component = $__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f; ?>
<?php unset($__componentOriginal8bb1ba37a24bf4d7a35d5445e54e447f); ?>
<?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $attributes = $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $component = $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
            <?php $__env->startPush('js'); ?>
                <script src="sweetalert2.all.min.js"></script>
                <script>
                    Livewire.on('sistema1', maquina => { 
                            Swal.fire({
                            title: "¿<?php echo e(__('Are you sure to ENABLE the system')); ?>?",
                            text: "<?php echo e(__('All features will be available')); ?>",
                            icon: 'warning',
                            cancelButtonText: '<?php echo e(__("Cancel")); ?>',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: '¡<?php echo e(__("Yes, Im sure")); ?>!'
                        })
                        .then((result) => {
                            if (result.isConfirmed) {
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('update_sistema', maquina)
        
                                Swal.fire(
                                    '',
                                    '<?php echo e(__("Sent.")); ?>',
                                    'success'
                                )
                            }
                        })
                    });
        
                    Livewire.on('sistema2', maquina => { 
                            Swal.fire({
                            title: "¿<?php echo e(__('Are you sure to DISABLE the system')); ?>?",
                            text: "<?php echo e(__('Only manual output will remain active')); ?>",
                            icon: 'warning',
                            cancelButtonText: '<?php echo e(__("Cancel")); ?>',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: '¡<?php echo e(__("Yes, Im sure")); ?>!'
                        })
                        .then((result) => {
                            if (result.isConfirmed) {
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('update_sistema', maquina)
        
                                Swal.fire(
                                    '',
                                    '<?php echo e(__("Sent.")); ?>',
                                    'success'
                                )
                            }
                        })
                    });
                </script>
            <?php $__env->stopPush(); ?>
        </div>
        
        <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
        
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal469697c8a3c244cba6b653458854f352)): ?>
<?php $attributes = $__attributesOriginal469697c8a3c244cba6b653458854f352; ?>
<?php unset($__attributesOriginal469697c8a3c244cba6b653458854f352); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal469697c8a3c244cba6b653458854f352)): ?>
<?php $component = $__componentOriginal469697c8a3c244cba6b653458854f352; ?>
<?php unset($__componentOriginal469697c8a3c244cba6b653458854f352); ?>
<?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\multifactor1-new\resources\views/livewire/franquiciado/dashboard-f.blade.php ENDPATH**/ ?>