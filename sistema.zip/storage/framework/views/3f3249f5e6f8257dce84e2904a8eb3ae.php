<?php

use App\Events\MessageSent;
use Livewire\Attributes\On;
use Livewire\Volt\Component;
use App\Models\Maquina;
use App\Models\MaquinasSalida;
use App\Models\Dia;
use App\Models\Minuto;
use App\Models\Hora;

?>

<div class="container">
    <span class="text-2xl font-semi-bold leading-normal">Dashboard</span>
    <div class="col-12" style="overflow-x: auto">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 my-4 p-2 rounded">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-full">
                    <div class="relative w-full px-4 py-6 bg-white shadow-lg dark:bg-gray-700 rounded">
                        <div class="mb-4">
                            <div class="flex items-center justify-between mb-2">
                                <div class="flex items-center">
                                    <span class="relative p-2 fondo-primero rounded-xl">

                                    </span>
                                    <div class="flex flex-col">
                                        <span class="ml-2 font-bold texto-primero text-md dark:text-white">
                                            <?php echo e($maq->nombre); ?>

                                            <span class="ml-2 text-xs text-gray-500 dark:text-white">
                                                (<?php echo e("ID ".$maq->id_maquina); ?>)
                                            </span>
                                        </span>
                                        <span class="ml-2 text-sm text-gray-500 dark:text-white">
                                            <!--[if BLOCK]><![endif]--><?php if($maq->dia_id <> ''): ?>
                                                <?php echo e($maq->reloj." - ".$maq->maquina_dia->dias); ?>

                                            <?php else: ?>
                                                <?php echo e($maq->reloj); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <button class="p-1 mr-0 text-sm text-gray-400">
                                    </button>
                                </div>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $maquinas_salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!--[if BLOCK]><![endif]--><?php if($sal->maquina_id == $maq->id): ?>
                                    <div class="flex items-center justify-between ">
                                        <p class="font-bold texto-primero text-md dark:text-white">
                                            <?php echo e($sal->nombre); ?>

                                            <!--[if BLOCK]><![endif]--><?php if($maq->estatus_maquina_id == 0 ): ?>
                                                <span class="badge p-0.5 pl-1 pr-1 rounded" style="background-color: #f9e79f; color: #9a7d0a; font-size:0.6em; margin-top:0px">Disable</span>
                                            <?php else: ?>
                                                <span class="badge p-0.5 pl-1 pr-1 rounded" style="background-color: #a9dfbf; color: #186a3b; font-size:0.6em; margin-top:0px">Enabled</span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                            <!--[if BLOCK]><![endif]--><?php if($maq->estatus_estado_id == 1 or $maq->estatus_estado_id == 2 or $maq->estatus_estado_id == 4 ): ?>
                                                <span class="badge p-0.5 pl-1 pr-1 rounded" style="background-color: #a9dfbf; color: #186a3b; font-size:0.6em; margin-top:5px">ON</span>
                                            <?php else: ?>
                                                <span class="badge p-0.5 pl-1 pr-1 rounded" style="background-color: #f9e79f; color: #9a7d0a; font-size:0.6em; margin-top:5px">OFF</span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </p>
                                        <button class="p-1 mr-0 text-sm text-gray-400">
                                        </button>
                                    </div>
                                    <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-0 p-0 rounded">
                                        <span class="ml-0 text-xs text-gray-500 dark:text-white">
                                            <?php echo e("Last update: ".date("d/m/Y H:i:s",strtotime($sal->updated_at))); ?>

                                        </span>
                                    </div>

                                    <!--[if BLOCK]><![endif]--><?php if($sal->uno == 69): ?>
                                        <?php
                                        $resultado = 0;
                                        $letra=$sal->uno;
                                        ?>
                                    <?php else: ?>
                                        <!--[if BLOCK]><![endif]--><?php if($sal->uno == 86): ?>
                                            <?php
                                            $letra="V";
                                            ?>
                                        <?php else: ?>
                                            <?php
                                            $letra=$sal->uno;
                                            ?>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php
                                        $resultado = (($sal->tres * 256) + $sal->cuatro) / 10;
                                        ?>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            
                                    <!--[if BLOCK]><![endif]--><?php if($sal->estatus_estado_id == 0 or $sal->estatus_estado_id == 3): ?>
                                        <?php
                                        $tem = "- °C";
                                        $set = "- °C";
                                        ?>
                                    <?php else: ?>
                                        <!--[if BLOCK]><![endif]--><?php if($sal->point == ""): ?>
                                            <?php
                                            $tem = "- °C";
                                            $set = "- °C";
                                            ?>
                                        <?php else: ?>
                                            <!--[if BLOCK]><![endif]--><?php if($sal->dos == 254 or $sal->dos == 255): ?>
                                                <?php
                                                $tem = "- °C";
                                                $set = "- °C";
                                                ?>
                                            <?php else: ?>
                                                <?php
                                                $tem = $resultado." °C";
                                                $set = $sal->point." °C";
                                                ?>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            
                                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-2 p-2 rounded">
                                        <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                            <div class="flex items-center text-xs dark:text-white text-center">
                                                <i class="icofont icofont-stopwatch mr-2" style="font-size:1.7em"></i>
                                                Turn On
                                            </div>
                                            <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                <?php echo e($sal->hora_encendido); ?>

                                            </div>
                                        </div>
                                        <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                            <div class="flex items-center text-xs dark:text-white text-center">
                                                <i class="icofont icofont-stopwatch mr-2" style="font-size:1.7em"></i>
                                                Turn Off
                                            </div>
                                            <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                <?php echo e($sal->hora_apagado); ?>

                                            </div>
                                        </div>
                                        <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                            <div class="flex items-center text-xs dark:text-white text-center">
                                                <i class="icofont icofont-snow-temp mr-2" style="font-size:1.7em"></i>
                                                Temperature
                                            </div>
                                            <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                <?php echo e($tem); ?>

                                            </div>
                                        </div>
                                        <div class="flex-1 w-full text-center p-2 border-2 border-gray-100 rounded text-white fondo-primero">
                                            <div class="flex items-center text-xs dark:text-white text-center">
                                                <i class="icofont icofont-thermometer mr-2" style="font-size:1.7em"></i>
                                                Set Point
                                            </div>
                                            <div class="text-sm text-yellow-400 font-bold dark:text-gray-200">
                                                <?php echo e($set); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\multifactor1-new\resources\views\livewire/monitoreolectura.blade.php ENDPATH**/ ?>