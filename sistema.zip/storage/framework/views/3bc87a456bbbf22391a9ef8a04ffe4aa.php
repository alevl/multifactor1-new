<div>
    <?php if (isset($component)) { $__componentOriginalf357e1b43e2650a819b8907d5869a5c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf357e1b43e2650a819b8907d5869a5c4 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\MenuLectura::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.menu-lectura'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\MenuLectura::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('monitoreolectura', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2333216241-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf357e1b43e2650a819b8907d5869a5c4)): ?>
<?php $attributes = $__attributesOriginalf357e1b43e2650a819b8907d5869a5c4; ?>
<?php unset($__attributesOriginalf357e1b43e2650a819b8907d5869a5c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf357e1b43e2650a819b8907d5869a5c4)): ?>
<?php $component = $__componentOriginalf357e1b43e2650a819b8907d5869a5c4; ?>
<?php unset($__componentOriginalf357e1b43e2650a819b8907d5869a5c4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\multifactor1-new\resources\views/livewire/lectura/dashboard-read.blade.php ENDPATH**/ ?>