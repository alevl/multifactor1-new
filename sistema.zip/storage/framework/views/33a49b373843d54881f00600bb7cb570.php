<div>
    <?php if (isset($component)) { $__componentOriginal1242012248cb806a014cb84ec10983f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1242012248cb806a014cb84ec10983f1 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\MenuUser::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.menu-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\MenuUser::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('monitoreo', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2509859188-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1242012248cb806a014cb84ec10983f1)): ?>
<?php $attributes = $__attributesOriginal1242012248cb806a014cb84ec10983f1; ?>
<?php unset($__attributesOriginal1242012248cb806a014cb84ec10983f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1242012248cb806a014cb84ec10983f1)): ?>
<?php $component = $__componentOriginal1242012248cb806a014cb84ec10983f1; ?>
<?php unset($__componentOriginal1242012248cb806a014cb84ec10983f1); ?>
<?php endif; ?>
</div><?php /**PATH /var/www/vhosts/multifactor1.com/httpdocs/resources/views/livewire/user/dashboard.blade.php ENDPATH**/ ?>